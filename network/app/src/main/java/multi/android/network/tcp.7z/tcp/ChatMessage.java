package multi.android.network.tcp;

public class ChatMessage {
    String nickname;
    String msg;
}
